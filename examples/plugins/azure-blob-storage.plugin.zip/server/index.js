(() => {
  var __defProp = Object.defineProperty;
  var __returnValue = (v) => v;
  function __exportSetter(name, newValue) {
    this[name] = __returnValue.bind(null, newValue);
  }
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, {
        get: all[name],
        enumerable: true,
        configurable: true,
        set: __exportSetter.bind(all, name)
      });
  };

  // examples/plugins/azure-blob-storage/server/index.ts
  var exports_server = {};
  __export(exports_server, {
    default: () => server_default
  });

  // examples/plugins/azure-blob-storage/server/sas.ts
  var SIGNED_VERSION = "2024-11-04";
  var B64_CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
  function bytesToBase64(bytes) {
    let out = "";
    let i = 0;
    for (;i + 2 < bytes.length; i += 3) {
      const triplet = bytes[i] << 16 | bytes[i + 1] << 8 | bytes[i + 2];
      out += B64_CHARS[triplet >> 18 & 63] + B64_CHARS[triplet >> 12 & 63] + B64_CHARS[triplet >> 6 & 63] + B64_CHARS[triplet & 63];
    }
    const rem = bytes.length - i;
    if (rem === 1) {
      const a = bytes[i];
      out += B64_CHARS[a >> 2] + B64_CHARS[a << 4 & 63] + "==";
    } else if (rem === 2) {
      const a = bytes[i];
      const b = bytes[i + 1];
      out += B64_CHARS[a >> 2] + B64_CHARS[(a << 4 | b >> 4) & 63] + B64_CHARS[b << 2 & 63] + "=";
    }
    return out;
  }
  var B64_DECODE = (() => {
    const table = new Uint8Array(128);
    for (let i = 0;i < B64_CHARS.length; i++)
      table[B64_CHARS.charCodeAt(i)] = i;
    return table;
  })();
  function base64ToBytes(base64) {
    let padded = base64.replace(/[^A-Za-z0-9+/=]/g, "");
    while (padded.length % 4 !== 0)
      padded += "=";
    const padCount = padded.endsWith("==") ? 2 : padded.endsWith("=") ? 1 : 0;
    const byteLength = padded.length * 3 / 4 - padCount;
    const out = new Uint8Array(byteLength);
    let o = 0;
    for (let i = 0;i < padded.length; i += 4) {
      const a = B64_DECODE[padded.charCodeAt(i)] || 0;
      const b = B64_DECODE[padded.charCodeAt(i + 1)] || 0;
      const c = padded.charCodeAt(i + 2) === 61 ? 0 : B64_DECODE[padded.charCodeAt(i + 2)] || 0;
      const d = padded.charCodeAt(i + 3) === 61 ? 0 : B64_DECODE[padded.charCodeAt(i + 3)] || 0;
      out[o++] = a << 2 | b >> 4;
      if (o < byteLength)
        out[o++] = b << 4 & 255 | c >> 2;
      if (o < byteLength)
        out[o++] = c << 6 & 255 | d;
    }
    return out;
  }
  function utf8(s) {
    const out = [];
    for (let i = 0;i < s.length; i++) {
      const c = s.charCodeAt(i);
      if (c < 128) {
        out.push(c);
      } else if (c < 2048) {
        out.push(192 | c >> 6, 128 | c & 63);
      } else if (c >= 55296 && c <= 56319) {
        const next = s.charCodeAt(++i);
        const cp = 65536 + ((c & 1023) << 10 | next & 1023);
        out.push(240 | cp >> 18, 128 | cp >> 12 & 63, 128 | cp >> 6 & 63, 128 | cp & 63);
      } else {
        out.push(224 | c >> 12, 128 | c >> 6 & 63, 128 | c & 63);
      }
    }
    return new Uint8Array(out);
  }
  async function hmacSha256(key, data) {
    const cryptoKey = await crypto.subtle.importKey("raw", key, { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
    const dataBytes = typeof data === "string" ? utf8(data) : data;
    const sig = await crypto.subtle.sign({ name: "HMAC" }, cryptoKey, dataBytes);
    return new Uint8Array(sig);
  }
  function iso8601Seconds(date) {
    return date.toISOString().replace(/\.\d{3}Z$/, "Z");
  }
  function endpointSuffix(cloud) {
    switch (cloud) {
      case "usgov":
        return "blob.core.usgovcloudapi.net";
      case "china":
        return "blob.core.chinacloudapi.cn";
      case "public":
      default:
        return "blob.core.windows.net";
    }
  }
  function azureBlobHost(account, cloud) {
    return `${account}.${endpointSuffix(cloud)}`;
  }
  function canonicalizedResource(account, container, blob) {
    const base = `/blob/${account}/${container}`;
    if (!blob)
      return base;
    return `${base}/${decodeURIComponent(blob)}`;
  }
  function buildStringToSign(input) {
    return [
      input.signedPermissions,
      input.signedStart,
      input.signedExpiry,
      input.canonicalizedResource,
      input.signedIdentifier,
      input.signedIP,
      input.signedProtocol,
      input.signedVersion,
      input.signedResource,
      input.signedSnapshotTime,
      input.signedEncryptionScope,
      input.rscc,
      input.rscd,
      input.rsce,
      input.rscl,
      input.rsct
    ].join(`
`);
  }
  function encodeBlobPath(blob) {
    return blob.split("/").map((seg) => encodeURIComponent(seg)).join("/");
  }
  async function presignAzureBlobUrl(opts) {
    const now = new Date;
    const signedStart = "";
    const expiry = new Date(now.getTime() + opts.expiresInSeconds * 1000);
    const signedExpiry = iso8601Seconds(expiry);
    const canonicalResource = canonicalizedResource(opts.account, opts.container, opts.signedResource === "b" ? opts.blob : null);
    const stringToSign = buildStringToSign({
      signedPermissions: opts.permissions,
      signedStart,
      signedExpiry,
      canonicalizedResource: canonicalResource,
      signedIdentifier: "",
      signedIP: "",
      signedProtocol: "https",
      signedVersion: SIGNED_VERSION,
      signedResource: opts.signedResource,
      signedSnapshotTime: "",
      signedEncryptionScope: "",
      rscc: "",
      rscd: "",
      rsce: "",
      rscl: "",
      rsct: ""
    });
    const keyBytes = base64ToBytes(opts.accountKeyBase64);
    const sigBytes = await hmacSha256(keyBytes, stringToSign);
    const signature = bytesToBase64(sigBytes);
    const query = new URLSearchParams;
    if (signedStart)
      query.set("st", signedStart);
    query.set("se", signedExpiry);
    query.set("sp", opts.permissions);
    query.set("spr", "https");
    query.set("sv", SIGNED_VERSION);
    query.set("sr", opts.signedResource);
    query.set("sig", signature);
    const host = azureBlobHost(opts.account, opts.cloud);
    const pathBlob = opts.signedResource === "b" ? `/${encodeBlobPath(opts.blob)}` : "";
    const pathContainer = `/${opts.container}`;
    const url = `https://${host}${pathContainer}${pathBlob}?${query.toString()}`;
    return { url, expiresAtMs: expiry.getTime() };
  }

  // examples/plugins/azure-blob-storage/server/adapter.ts
  function readSettings(api) {
    const get = (key) => api.cms.settings.get(key);
    const required = {
      account: String(get("account") ?? ""),
      accountKey: String(get("accountKey") ?? ""),
      container: String(get("container") ?? "")
    };
    for (const [key, value] of Object.entries(required)) {
      if (!value) {
        throw new Error(`The "${key}" setting is empty — open the plugin's Settings dialog and fill it in.`);
      }
    }
    const cloudRaw = String(get("cloud") ?? "public");
    const cloud = cloudRaw === "usgov" ? "usgov" : cloudRaw === "china" ? "china" : "public";
    const servingModeRaw = String(get("servingMode") ?? "signed-redirect");
    const servingMode = servingModeRaw === "public-url" ? "public-url" : "signed-redirect";
    const publicUrlBaseRaw = String(get("publicUrlBase") ?? "").trim();
    const publicUrlBase = publicUrlBaseRaw ? publicUrlBaseRaw.endsWith("/") ? publicUrlBaseRaw : publicUrlBaseRaw + "/" : null;
    let pathPrefix = String(get("pathPrefix") ?? "").trim();
    while (pathPrefix.startsWith("/"))
      pathPrefix = pathPrefix.slice(1);
    if (pathPrefix && !pathPrefix.endsWith("/"))
      pathPrefix = pathPrefix + "/";
    return {
      account: required.account,
      accountKey: required.accountKey,
      container: required.container,
      cloud,
      servingMode,
      publicUrlBase,
      pathPrefix
    };
  }
  function blobName(settings, storagePath) {
    return settings.pathPrefix + storagePath;
  }
  function publicReadUrl(settings, storagePath) {
    const blob = blobName(settings, storagePath);
    if (settings.publicUrlBase) {
      return settings.publicUrlBase + blob;
    }
    return `https://${azureBlobHost(settings.account, settings.cloud)}/${settings.container}/${blob}`;
  }
  async function buildSinglePutPlan(settings, storagePath, mimeType) {
    const expiresInSeconds = 15 * 60;
    const presign = await presignAzureBlobUrl({
      account: settings.account,
      accountKeyBase64: settings.accountKey,
      cloud: settings.cloud,
      container: settings.container,
      blob: blobName(settings, storagePath),
      signedResource: "b",
      permissions: "cw",
      expiresInSeconds
    });
    return {
      storagePath,
      steps: [{
        method: "PUT",
        url: presign.url,
        headers: {
          "x-ms-blob-type": "BlockBlob",
          "Content-Type": mimeType
        }
      }],
      expiresAt: Date.now() + expiresInSeconds * 1000
    };
  }
  function buildAzureBlobAdapter(api) {
    const pluginId = api.plugin.id;
    return {
      id: `${pluginId}.adapter`,
      label: "Azure Blob Storage",
      roles: ["original", "variant"],
      servingMode: readSettings(api).servingMode,
      async beginWrite(input) {
        const settings = readSettings(api);
        return buildSinglePutPlan(settings, input.suggestedStoragePath, input.mimeType);
      },
      async finalizeWrite(input) {
        const settings = readSettings(api);
        const publicUrl = publicReadUrl(settings, input.storagePath);
        const etag = input.uploadReceipts[0]?.etag;
        return {
          publicUrl,
          ...etag ? { metadata: { etag } } : {}
        };
      },
      async abortWrite(input) {
        await issueSignedDelete(api, input.storagePath, 300);
      },
      async delete(storagePath) {
        await issueSignedDelete(api, storagePath, 300);
      },
      async getReadUrl(storagePath, ttlSeconds) {
        const settings = readSettings(api);
        const ttl = Math.max(60, Math.min(ttlSeconds, 86400));
        const presign = await presignAzureBlobUrl({
          account: settings.account,
          accountKeyBase64: settings.accountKey,
          cloud: settings.cloud,
          container: settings.container,
          blob: blobName(settings, storagePath),
          signedResource: "b",
          permissions: "r",
          expiresInSeconds: ttl
        });
        return { url: presign.url, expiresAt: Date.now() + ttl * 1000 };
      },
      async verify() {
        let settings;
        try {
          settings = readSettings(api);
        } catch (err) {
          return {
            ok: false,
            reason: err instanceof Error ? err.message : "Plugin settings missing",
            hint: "Open the plugin Settings dialog and fill in every required field, then save."
          };
        }
        if (!/^[a-z0-9]{3,24}$/.test(settings.account)) {
          return {
            ok: false,
            reason: `Account name "${settings.account}" is not a valid Azure storage account name.`,
            hint: "Azure storage account names are 3-24 chars, lowercase letters and digits only."
          };
        }
        if (!/^[a-z0-9](?:[a-z0-9]|-(?=[a-z0-9])){2,62}$/.test(settings.container)) {
          return {
            ok: false,
            reason: `Container name "${settings.container}" is not a valid Azure container name.`,
            hint: "Azure container names are 3-63 chars, lowercase letters / digits / hyphens, no leading or trailing hyphen, no consecutive hyphens."
          };
        }
        try {
          const presign = await presignAzureBlobUrl({
            account: settings.account,
            accountKeyBase64: settings.accountKey,
            cloud: settings.cloud,
            container: settings.container,
            blob: "",
            signedResource: "c",
            permissions: "rl",
            expiresInSeconds: 60
          });
          const listUrl = presign.url + "&restype=container&comp=list&maxresults=1";
          const response = await fetch(listUrl, { method: "GET" });
          if (response.ok)
            return { ok: true };
          return {
            ok: false,
            reason: `Azure returned ${response.status} ${response.statusText || ""}`.trim(),
            hint: response.status === 403 ? "Signature rejected. Most likely the Account Key is wrong — re-copy `key1` or `key2` from Azure portal → Storage account → Access keys. Also check the system clock isn't skewed." : response.status === 404 ? `Container "${settings.container}" not found on account "${settings.account}". Create it via Azure portal → Storage account → Containers, or fix the names in plugin settings.` : "Check the storage account name, the network connectivity to Azure, and the cloud setting (public / usgov / china)."
          };
        } catch (err) {
          return {
            ok: false,
            reason: err instanceof Error ? err.message : "fetch failed",
            hint: "Check that the Azure Blob endpoint is reachable from this server and allowed in the plugin manifest's networkAllowedHosts."
          };
        }
      },
      cspOrigins: [
        { directive: "img-src", origin: "*.blob.core.windows.net" },
        { directive: "img-src", origin: "*.blob.core.usgovcloudapi.net" },
        { directive: "img-src", origin: "*.blob.core.chinacloudapi.cn" },
        { directive: "media-src", origin: "*.blob.core.windows.net" },
        { directive: "media-src", origin: "*.blob.core.usgovcloudapi.net" },
        { directive: "media-src", origin: "*.blob.core.chinacloudapi.cn" }
      ]
    };
  }
  async function issueSignedDelete(api, storagePath, ttlSeconds) {
    const settings = readSettings(api);
    const presign = await presignAzureBlobUrl({
      account: settings.account,
      accountKeyBase64: settings.accountKey,
      cloud: settings.cloud,
      container: settings.container,
      blob: blobName(settings, storagePath),
      signedResource: "b",
      permissions: "d",
      expiresInSeconds: ttlSeconds
    });
    try {
      await fetch(presign.url, { method: "DELETE" });
    } catch (err) {
      api.plugin.log(`[azure] DELETE "${storagePath}" failed (orphaned):`, err);
    }
  }

  // examples/plugins/azure-blob-storage/server/index.ts
  var mod = {
    install(api) {
      api.plugin.log("Azure Blob Storage installed. Open the plugin's Settings dialog, fill in the storage account, account key, and container, then elect it in the Media → Storage panel.");
    },
    async activate(api) {
      const adapter = buildAzureBlobAdapter(api);
      api.cms.media.registerStorageAdapter(adapter);
      api.plugin.log(`Registered "${adapter.label}" adapter (id: ${adapter.id}).`);
    }
  };
  var server_default = mod;

  // examples/plugins/azure-blob-storage/server/__sandbox-facade-1780347350704.ts
  var __default = exports_server && server_default;
  var __isPluginModule = (v) => v && typeof v === "object" && (typeof v.install === "function" || typeof v.activate === "function" || typeof v.deactivate === "function" || typeof v.uninstall === "function" || typeof v.migrate === "function");
  globalThis.__plugin_exports = __isPluginModule(__default) ? __default : exports_server;
})();
