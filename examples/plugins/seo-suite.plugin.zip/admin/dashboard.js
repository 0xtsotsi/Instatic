// examples/plugins/seo-suite/admin/dashboard.tsx
import { useCallback, useEffect, useState } from "react";
import {
  Alert,
  Button,
  Card,
  EmptyState,
  Heading,
  Input,
  Stack,
  StatValue,
  Switch,
  Text,
  Textarea
} from "@instatic/host-ui";
import { usePluginRoutes } from "@instatic/host-hooks";
import { definePluginAdminApp } from "@instatic/plugin-sdk";
import { jsx, jsxs } from "react/jsx-runtime";
function StatCard({ label, value, detail }) {
  return /* @__PURE__ */ jsx(Card, {
    padding: 16,
    children: /* @__PURE__ */ jsxs(Stack, {
      gap: 4,
      children: [
        /* @__PURE__ */ jsx(Text, {
          variant: "muted",
          children: label
        }),
        /* @__PURE__ */ jsx(StatValue, {
          value,
          sub: detail ? /* @__PURE__ */ jsx("span", {
            children: detail
          }) : undefined
        })
      ]
    })
  });
}
function StatusBadge({ tone, label }) {
  const colors = {
    success: { bg: "var(--editor-success-bg)", text: "var(--editor-success-green)" },
    warning: { bg: "var(--editor-warning-bg, rgba(251,188,4,0.12))", text: "var(--editor-warning)" },
    danger: { bg: "var(--editor-danger-bg)", text: "var(--editor-danger)" },
    muted: { bg: "var(--panel-border)", text: "var(--editor-text-muted)" }
  };
  const c = colors[tone];
  return /* @__PURE__ */ jsx("span", {
    style: {
      display: "inline-block",
      padding: "2px 8px",
      fontSize: 11,
      fontWeight: 600,
      textTransform: "uppercase",
      letterSpacing: "0.04em",
      borderRadius: 4,
      background: c.bg,
      color: c.text
    },
    children: label
  });
}
function EntryEditor({ pageId, initial, onSave, onCancel }) {
  const [form, setForm] = useState({ ...initial, "page-id": pageId });
  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState(null);
  function update(field, value) {
    setForm((prev) => ({ ...prev, [field]: value }));
  }
  async function handleSave() {
    setSaving(true);
    setSaveError(null);
    try {
      await onSave(form);
    } catch (err) {
      setSaveError(err instanceof Error ? err.message : "Save failed");
    } finally {
      setSaving(false);
    }
  }
  return /* @__PURE__ */ jsx(Card, {
    padding: 16,
    children: /* @__PURE__ */ jsxs(Stack, {
      gap: 12,
      children: [
        /* @__PURE__ */ jsxs(Heading, {
          level: 4,
          children: [
            "Edit SEO — ",
            pageId
          ]
        }),
        saveError && /* @__PURE__ */ jsx(Alert, {
          tone: "danger",
          title: "Save failed",
          children: saveError
        }),
        /* @__PURE__ */ jsx(Input, {
          label: "Title override",
          value: form["title-override"] ?? "",
          placeholder: "Leave blank to use the page's <title>",
          onChange: (v) => update("title-override", v)
        }),
        /* @__PURE__ */ jsx(Textarea, {
          label: "Meta description",
          value: form["meta-description"] ?? "",
          placeholder: "160 character summary for search results",
          rows: 3,
          onChange: (v) => update("meta-description", v)
        }),
        /* @__PURE__ */ jsx(Input, {
          label: "OG title",
          value: form["og-title"] ?? "",
          placeholder: "Social card title (defaults to title override)",
          onChange: (v) => update("og-title", v)
        }),
        /* @__PURE__ */ jsx(Textarea, {
          label: "OG description",
          value: form["og-description"] ?? "",
          placeholder: "Social card description",
          rows: 2,
          onChange: (v) => update("og-description", v)
        }),
        /* @__PURE__ */ jsx(Input, {
          label: "OG image URL",
          value: form["og-image-url"] ?? "",
          placeholder: "https://example.com/og.png",
          onChange: (v) => update("og-image-url", v)
        }),
        /* @__PURE__ */ jsx(Input, {
          label: "Twitter card type",
          value: form["twitter-card"] ?? "summary_large_image",
          placeholder: "summary_large_image",
          onChange: (v) => update("twitter-card", v)
        }),
        /* @__PURE__ */ jsx(Input, {
          label: "Canonical URL",
          value: form["canonical-url"] ?? "",
          placeholder: "https://example.com/page",
          onChange: (v) => update("canonical-url", v)
        }),
        /* @__PURE__ */ jsx(Textarea, {
          label: "Custom JSON-LD (optional)",
          value: form["json-ld"] ?? "",
          placeholder: '{"@context":"https://schema.org","@type":"Article",...}',
          rows: 4,
          onChange: (v) => update("json-ld", v)
        }),
        /* @__PURE__ */ jsxs(Stack, {
          direction: "row",
          gap: 8,
          children: [
            /* @__PURE__ */ jsx(Switch, {
              label: "No-index",
              checked: Boolean(form["no-index"]),
              description: "Prevent search engines from indexing this page.",
              onChange: (v) => update("no-index", v)
            }),
            /* @__PURE__ */ jsx(Switch, {
              label: "No-follow",
              checked: Boolean(form["no-follow"]),
              description: "Tell crawlers not to follow links on this page.",
              onChange: (v) => update("no-follow", v)
            })
          ]
        }),
        /* @__PURE__ */ jsxs(Stack, {
          direction: "row",
          gap: 8,
          children: [
            /* @__PURE__ */ jsx(Button, {
              variant: "primary",
              size: "sm",
              onClick: () => void handleSave(),
              disabled: saving,
              children: saving ? "Saving…" : "Save"
            }),
            /* @__PURE__ */ jsx(Button, {
              variant: "secondary",
              size: "sm",
              onClick: onCancel,
              disabled: saving,
              children: "Cancel"
            })
          ]
        })
      ]
    })
  });
}
function PageRow({ row, expanded, onToggle, onSave }) {
  const entry = row.seoEntry ?? {};
  const hasDesc = Boolean(entry["meta-description"]);
  const hasOg = Boolean(entry["og-image-url"]);
  const noIndex = Boolean(entry["no-index"]);
  return /* @__PURE__ */ jsxs(Stack, {
    gap: 8,
    children: [
      /* @__PURE__ */ jsx(Card, {
        padding: 12,
        children: /* @__PURE__ */ jsxs(Stack, {
          direction: "row",
          gap: 12,
          align: "center",
          children: [
            /* @__PURE__ */ jsxs(Stack, {
              gap: 2,
              style: { flex: 1, minWidth: 0 },
              children: [
                /* @__PURE__ */ jsx(Text, {
                  variant: "strong",
                  children: row.title || row.pageId
                }),
                /* @__PURE__ */ jsx(Text, {
                  variant: "muted",
                  children: row.slug || row.url || row.pageId
                })
              ]
            }),
            /* @__PURE__ */ jsxs(Stack, {
              direction: "row",
              gap: 4,
              align: "center",
              wrap: true,
              children: [
                /* @__PURE__ */ jsx(StatusBadge, {
                  tone: hasDesc ? "success" : "warning",
                  label: hasDesc ? "Has desc" : "No desc"
                }),
                /* @__PURE__ */ jsx(StatusBadge, {
                  tone: hasOg ? "success" : "warning",
                  label: hasOg ? "Has OG" : "No OG"
                }),
                noIndex ? /* @__PURE__ */ jsx(StatusBadge, {
                  tone: "danger",
                  label: "no-index"
                }) : /* @__PURE__ */ jsx(StatusBadge, {
                  tone: "success",
                  label: "indexable"
                })
              ]
            }),
            /* @__PURE__ */ jsx(Button, {
              variant: "ghost",
              size: "sm",
              onClick: onToggle,
              children: expanded ? "Close" : "Edit SEO"
            })
          ]
        })
      }),
      expanded && /* @__PURE__ */ jsx(EntryEditor, {
        pageId: row.pageId,
        initial: entry,
        onSave,
        onCancel: onToggle
      })
    ]
  });
}
function SeoSuiteDashboard() {
  const routes = usePluginRoutes();
  const [entries, setEntries] = useState([]);
  const [pages, setPages] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [expandedPageId, setExpandedPageId] = useState(null);
  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [entriesRes, pagesRes] = await Promise.all([
        routes.fetch("seo-entries"),
        routes.fetch("page-index")
      ]);
      const entriesBody = await entriesRes.json();
      const pagesBody = await pagesRes.json();
      if (!entriesBody.ok)
        throw new Error(entriesBody.error ?? "Failed to load SEO entries");
      if (!pagesBody.ok)
        throw new Error(pagesBody.error ?? "Failed to load page index");
      setEntries(entriesBody.entries ?? []);
      setPages(pagesBody.pages ?? []);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load data");
    } finally {
      setLoading(false);
    }
  }, [routes]);
  useEffect(() => {
    load();
  }, [load]);
  const entriesByPageId = new Map;
  for (const record of entries) {
    entriesByPageId.set(record.data["page-id"], record.data);
  }
  const seen = new Set;
  const rows = [];
  for (const page of pages) {
    const pageId = page.data["page-id"];
    if (!pageId)
      continue;
    seen.add(pageId);
    rows.push({
      pageId,
      title: page.data.title ?? "",
      slug: page.data.slug ?? "",
      url: page.data.url ?? "",
      seoEntry: entriesByPageId.get(pageId) ?? null
    });
  }
  for (const record of entries) {
    const pageId = record.data["page-id"];
    if (!pageId || seen.has(pageId))
      continue;
    seen.add(pageId);
    rows.push({
      pageId,
      title: record.data["last-rendered-title"] ?? "",
      slug: "",
      url: record.data["last-rendered-url"] ?? "",
      seoEntry: record.data
    });
  }
  const totalPages = rows.length;
  const withDesc = rows.filter((r) => Boolean(r.seoEntry?.["meta-description"])).length;
  const withOg = rows.filter((r) => Boolean(r.seoEntry?.["og-image-url"])).length;
  const indexable = rows.filter((r) => !r.seoEntry?.["no-index"]).length;
  const pct = (n) => totalPages === 0 ? "—" : `${Math.round(n / totalPages * 100)}%`;
  async function handleSave(entry) {
    const res = await routes.fetch("seo-entries", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(entry)
    });
    const body = await res.json();
    if (!body.ok)
      throw new Error(body.error ?? "Save failed");
    await load();
    setExpandedPageId(null);
  }
  return /* @__PURE__ */ jsxs(Stack, {
    gap: 20,
    children: [
      /* @__PURE__ */ jsx(Heading, {
        level: 2,
        children: "SEO Suite"
      }),
      error && /* @__PURE__ */ jsx(Alert, {
        tone: "danger",
        title: "Error loading SEO data",
        children: error
      }),
      /* @__PURE__ */ jsxs(Stack, {
        direction: "row",
        gap: 12,
        wrap: true,
        children: [
          /* @__PURE__ */ jsx(StatCard, {
            label: "Total pages",
            value: String(totalPages),
            detail: "in page index"
          }),
          /* @__PURE__ */ jsx(StatCard, {
            label: "With description",
            value: pct(withDesc),
            detail: `${withDesc} of ${totalPages}`
          }),
          /* @__PURE__ */ jsx(StatCard, {
            label: "With OG image",
            value: pct(withOg),
            detail: `${withOg} of ${totalPages}`
          }),
          /* @__PURE__ */ jsx(StatCard, {
            label: "Indexable",
            value: pct(indexable),
            detail: `${indexable} of ${totalPages}`
          })
        ]
      }),
      loading && /* @__PURE__ */ jsx(Text, {
        variant: "muted",
        children: "Loading…"
      }),
      !loading && rows.length === 0 && /* @__PURE__ */ jsx(EmptyState, {
        title: "No pages found",
        body: "Add pages in the site editor and publish them to see their SEO health here."
      }),
      !loading && rows.length > 0 && /* @__PURE__ */ jsxs(Stack, {
        gap: 8,
        children: [
          /* @__PURE__ */ jsxs(Stack, {
            direction: "row",
            gap: 8,
            align: "center",
            children: [
              /* @__PURE__ */ jsx(Heading, {
                level: 3,
                children: "Pages"
              }),
              /* @__PURE__ */ jsx(Button, {
                variant: "secondary",
                size: "sm",
                onClick: () => void load(),
                disabled: loading,
                children: "Refresh"
              })
            ]
          }),
          /* @__PURE__ */ jsx(Stack, {
            gap: 4,
            children: rows.map((row) => /* @__PURE__ */ jsx(PageRow, {
              row,
              expanded: expandedPageId === row.pageId,
              onToggle: () => setExpandedPageId((prev) => prev === row.pageId ? null : row.pageId),
              onSave: handleSave
            }, row.pageId))
          })
        ]
      }),
      /* @__PURE__ */ jsxs(Text, {
        variant: "muted",
        children: [
          "Configure global SEO defaults (site URL, OG image, robots.txt) in the",
          " ",
          /* @__PURE__ */ jsx("strong", {
            children: "Settings"
          }),
          " panel on the plugin card."
        ]
      })
    ]
  });
}
var dashboard_default = definePluginAdminApp(SeoSuiteDashboard);
export {
  dashboard_default as default
};
