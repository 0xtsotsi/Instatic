(() => {
  var __defProp = Object.defineProperty;
  var __returnValue = (v) => v;
  function __exportSetter(name, newValue) {
    this[name] = __returnValue.bind(null, newValue);
  }
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, {
        get: all[name],
        enumerable: true,
        configurable: true,
        set: __exportSetter.bind(all, name)
      });
  };

  // examples/plugins/gcs-storage/server/index.ts
  var exports_server = {};
  __export(exports_server, {
    default: () => server_default
  });

  // examples/plugins/gcs-storage/server/sigv4.ts
  function utf8(s) {
    const out = [];
    for (let i = 0;i < s.length; i++) {
      const c = s.charCodeAt(i);
      if (c < 128) {
        out.push(c);
      } else if (c < 2048) {
        out.push(192 | c >> 6, 128 | c & 63);
      } else if (c >= 55296 && c <= 56319) {
        const next = s.charCodeAt(++i);
        const cp = 65536 + ((c & 1023) << 10 | next & 1023);
        out.push(240 | cp >> 18, 128 | cp >> 12 & 63, 128 | cp >> 6 & 63, 128 | cp & 63);
      } else {
        out.push(224 | c >> 12, 128 | c >> 6 & 63, 128 | c & 63);
      }
    }
    return new Uint8Array(out);
  }
  function bytesToHex(bytes) {
    let hex = "";
    for (let i = 0;i < bytes.length; i++)
      hex += bytes[i].toString(16).padStart(2, "0");
    return hex;
  }
  async function sha256(input) {
    const data = typeof input === "string" ? utf8(input) : input;
    const buf = await crypto.subtle.digest("SHA-256", data);
    return new Uint8Array(buf);
  }
  async function hmacSha256(key, data) {
    const cryptoKey = await crypto.subtle.importKey("raw", key, { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
    const dataBytes = typeof data === "string" ? utf8(data) : data;
    const sig = await crypto.subtle.sign({ name: "HMAC" }, cryptoKey, dataBytes);
    return new Uint8Array(sig);
  }
  function rfc3986Encode(s) {
    return encodeURIComponent(s).replace(/[!*'()]/g, (c) => "%" + c.charCodeAt(0).toString(16).toUpperCase());
  }
  function canonicalQuery(params) {
    const keys = Object.keys(params).sort();
    return keys.map((k) => `${rfc3986Encode(k)}=${rfc3986Encode(params[k])}`).join("&");
  }
  function encodeS3Key(key) {
    return key.split("/").map((segment) => rfc3986Encode(segment)).join("/");
  }
  async function s3SigningKey(secret, dateStamp, region) {
    const k1 = await hmacSha256(utf8("AWS4" + secret), dateStamp);
    const k2 = await hmacSha256(k1, region);
    const k3 = await hmacSha256(k2, "s3");
    return hmacSha256(k3, "aws4_request");
  }
  async function presignS3Url(opts) {
    const now = new Date;
    const iso = now.toISOString();
    const amzDate = `${iso.slice(0, 4)}${iso.slice(5, 7)}${iso.slice(8, 10)}T${iso.slice(11, 13)}${iso.slice(14, 16)}${iso.slice(17, 19)}Z`;
    const dateStamp = amzDate.slice(0, 8);
    const credentialScope = `${dateStamp}/${opts.region}/s3/aws4_request`;
    const signedHeaders = "host";
    const query = {
      "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
      "X-Amz-Credential": `${opts.accessKeyId}/${credentialScope}`,
      "X-Amz-Date": amzDate,
      "X-Amz-Expires": String(opts.expiresInSeconds),
      "X-Amz-SignedHeaders": signedHeaders,
      ...opts.sessionToken ? { "X-Amz-Security-Token": opts.sessionToken } : {},
      ...opts.extraQuery ?? {}
    };
    const canonicalQs = canonicalQuery(query);
    const canonicalUri = "/" + encodeS3Key(opts.key);
    const canonicalHeaders = `host:${opts.host}
`;
    const payloadHash = "UNSIGNED-PAYLOAD";
    const canonicalRequest = [
      opts.method,
      canonicalUri,
      canonicalQs,
      canonicalHeaders,
      signedHeaders,
      payloadHash
    ].join(`
`);
    const canonicalRequestHash = bytesToHex(await sha256(canonicalRequest));
    const stringToSign = ["AWS4-HMAC-SHA256", amzDate, credentialScope, canonicalRequestHash].join(`
`);
    const signingKey = await s3SigningKey(opts.secretAccessKey, dateStamp, opts.region);
    const signatureBytes = await hmacSha256(signingKey, stringToSign);
    const signature = bytesToHex(signatureBytes);
    const finalQuery = `${canonicalQs}&X-Amz-Signature=${signature}`;
    return {
      url: `https://${opts.host}${canonicalUri}?${finalQuery}`,
      amzDateIso: amzDate
    };
  }

  // examples/plugins/gcs-storage/server/adapter.ts
  var GCS_REGION = "auto";
  var GCS_HOST = "storage.googleapis.com";
  function readSettings(api) {
    const get = (key) => api.cms.settings.get(key);
    const required = {
      accessKeyId: String(get("accessKeyId") ?? ""),
      secretAccessKey: String(get("secretAccessKey") ?? ""),
      bucket: String(get("bucket") ?? "")
    };
    for (const [key, value] of Object.entries(required)) {
      if (!value) {
        throw new Error(`The "${key}" setting is empty — open the plugin's Settings dialog and fill it in.`);
      }
    }
    const servingModeRaw = String(get("servingMode") ?? "signed-redirect");
    const servingMode = servingModeRaw === "public-url" ? "public-url" : "signed-redirect";
    const publicUrlBaseRaw = String(get("publicUrlBase") ?? "").trim();
    const publicUrlBase = publicUrlBaseRaw ? publicUrlBaseRaw.endsWith("/") ? publicUrlBaseRaw : publicUrlBaseRaw + "/" : null;
    let pathPrefix = String(get("pathPrefix") ?? "").trim();
    while (pathPrefix.startsWith("/"))
      pathPrefix = pathPrefix.slice(1);
    if (pathPrefix && !pathPrefix.endsWith("/"))
      pathPrefix = pathPrefix + "/";
    return {
      accessKeyId: required.accessKeyId,
      secretAccessKey: required.secretAccessKey,
      bucket: required.bucket,
      servingMode,
      publicUrlBase,
      pathPrefix
    };
  }
  function gcsKey(settings, storagePath) {
    return `${settings.bucket}/${settings.pathPrefix}${storagePath}`;
  }
  function publicReadUrl(settings, storagePath) {
    if (settings.publicUrlBase) {
      return settings.publicUrlBase + settings.pathPrefix + storagePath;
    }
    return `https://${GCS_HOST}/${gcsKey(settings, storagePath)}`;
  }
  async function buildSinglePutPlan(settings, storagePath, mimeType) {
    const expiresInSeconds = 15 * 60;
    const presign = await presignS3Url({
      accessKeyId: settings.accessKeyId,
      secretAccessKey: settings.secretAccessKey,
      region: GCS_REGION,
      host: GCS_HOST,
      key: gcsKey(settings, storagePath),
      method: "PUT",
      expiresInSeconds
    });
    return {
      storagePath,
      steps: [{
        method: "PUT",
        url: presign.url,
        headers: { "Content-Type": mimeType }
      }],
      expiresAt: Date.now() + expiresInSeconds * 1000
    };
  }
  function buildGcsAdapter(api) {
    const pluginId = api.plugin.id;
    return {
      id: `${pluginId}.adapter`,
      label: "Google Cloud Storage",
      roles: ["original", "variant"],
      servingMode: readSettings(api).servingMode,
      async beginWrite(input) {
        const settings = readSettings(api);
        return buildSinglePutPlan(settings, input.suggestedStoragePath, input.mimeType);
      },
      async finalizeWrite(input) {
        const settings = readSettings(api);
        const publicUrl = publicReadUrl(settings, input.storagePath);
        const etag = input.uploadReceipts[0]?.etag;
        return {
          publicUrl,
          ...etag ? { metadata: { etag } } : {}
        };
      },
      async abortWrite(input) {
        await issueSignedRequest(api, "DELETE", input.storagePath, 300);
      },
      async delete(storagePath) {
        await issueSignedRequest(api, "DELETE", storagePath, 300);
      },
      async getReadUrl(storagePath, ttlSeconds) {
        const settings = readSettings(api);
        const presign = await presignS3Url({
          accessKeyId: settings.accessKeyId,
          secretAccessKey: settings.secretAccessKey,
          region: GCS_REGION,
          host: GCS_HOST,
          key: gcsKey(settings, storagePath),
          method: "GET",
          expiresInSeconds: Math.max(60, Math.min(ttlSeconds, 7 * 24 * 60 * 60))
        });
        return { url: presign.url, expiresAt: Date.now() + ttlSeconds * 1000 };
      },
      async verify() {
        let settings;
        try {
          settings = readSettings(api);
        } catch (err) {
          return {
            ok: false,
            reason: err instanceof Error ? err.message : "Plugin settings missing",
            hint: "Open the plugin Settings dialog and fill in every required field, then save."
          };
        }
        if (!settings.accessKeyId.startsWith("GOOG")) {
          return {
            ok: false,
            reason: `Access ID "${settings.accessKeyId.slice(0, 8)}…" doesn't start with "GOOG".`,
            hint: "GCS HMAC access IDs always start with GOOG. Make sure you created an interoperability HMAC key (Cloud Console → Cloud Storage → Settings → Interoperability), not a service-account JSON key."
          };
        }
        try {
          const presign = await presignS3Url({
            accessKeyId: settings.accessKeyId,
            secretAccessKey: settings.secretAccessKey,
            region: GCS_REGION,
            host: GCS_HOST,
            key: settings.bucket,
            method: "HEAD",
            expiresInSeconds: 60
          });
          const response = await fetch(presign.url, { method: "HEAD" });
          if (response.ok)
            return { ok: true };
          return {
            ok: false,
            reason: `GCS returned ${response.status} ${response.statusText || ""}`.trim(),
            hint: response.status === 403 ? 'The HMAC key works but the associated service account lacks `storage.objects.create` / `storage.objects.get` / `storage.buckets.get` on this bucket. Grant the "Storage Object Admin" role on the bucket and try again.' : response.status === 404 ? "Bucket not found. Verify the bucket name and that the HMAC key's service account has access." : "Check the HMAC access ID + secret, and that storage.googleapis.com is reachable."
          };
        } catch (err) {
          return {
            ok: false,
            reason: err instanceof Error ? err.message : "fetch failed",
            hint: "Check that storage.googleapis.com is reachable from this server."
          };
        }
      },
      cspOrigins: [
        { directive: "img-src", origin: "storage.googleapis.com" },
        { directive: "img-src", origin: "*.storage.googleapis.com" },
        { directive: "media-src", origin: "storage.googleapis.com" },
        { directive: "media-src", origin: "*.storage.googleapis.com" }
      ]
    };
  }
  async function issueSignedRequest(api, method, storagePath, ttlSeconds) {
    const settings = readSettings(api);
    const presign = await presignS3Url({
      accessKeyId: settings.accessKeyId,
      secretAccessKey: settings.secretAccessKey,
      region: GCS_REGION,
      host: GCS_HOST,
      key: gcsKey(settings, storagePath),
      method,
      expiresInSeconds: ttlSeconds
    });
    try {
      await fetch(presign.url, { method });
    } catch (err) {
      api.plugin.log(`[gcs] ${method} "${storagePath}" failed (orphaned):`, err);
    }
  }

  // examples/plugins/gcs-storage/server/index.ts
  var mod = {
    install(api) {
      api.plugin.log("Google Cloud Storage installed. Open the plugin's Settings dialog, fill in the HMAC access ID + secret + bucket, then elect it in the Media → Storage panel.");
    },
    async activate(api) {
      const adapter = buildGcsAdapter(api);
      api.cms.media.registerStorageAdapter(adapter);
      api.plugin.log(`Registered "${adapter.label}" adapter (id: ${adapter.id}).`);
    }
  };
  var server_default = mod;

  // examples/plugins/gcs-storage/server/__sandbox-facade-1780347350879.ts
  var __default = exports_server && server_default;
  var __isPluginModule = (v) => v && typeof v === "object" && (typeof v.install === "function" || typeof v.activate === "function" || typeof v.deactivate === "function" || typeof v.uninstall === "function" || typeof v.migrate === "function");
  globalThis.__plugin_exports = __isPluginModule(__default) ? __default : exports_server;
})();
